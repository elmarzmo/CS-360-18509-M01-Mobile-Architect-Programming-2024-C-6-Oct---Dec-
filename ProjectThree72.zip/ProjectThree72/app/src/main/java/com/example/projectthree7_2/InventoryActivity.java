package com.example.projectthree7_2;

import android.database.Cursor;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class InventoryActivity extends AppCompatActivity {

    private UserDatabaseHelper dbHelper;
    private ListView inventoryListView;
    private Button addItemButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_inventory);

        dbHelper = new UserDatabaseHelper(this);

        inventoryListView = findViewById(R.id.inventoryListView);
        addItemButton = findViewById(R.id.addItemButton);

        // Add inventory item
        addItemButton.setOnClickListener(v -> {
            dbHelper.addInventoryItem("Sample Item", 10, "This is a sample item.");
            Toast.makeText(InventoryActivity.this, "Item added", Toast.LENGTH_SHORT).show();
            displayInventory();
        });

        displayInventory();
    }

    // Display inventory items in a ListView
    private void displayInventory() {
        Cursor cursor = dbHelper.getAllInventoryItems();
        if (cursor != null) {
            // Assuming a custom adapter is used to display the data
            InventoryAdapter adapter = new InventoryAdapter(this, cursor);
            inventoryListView.setAdapter(adapter);
        }
    }
}
