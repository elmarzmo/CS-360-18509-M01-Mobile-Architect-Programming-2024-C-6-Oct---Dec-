package com.example.projectthree7_2;



import android.content.Context;
import android.database.Cursor;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.cursoradapter.widget.CursorAdapter;

public class InventoryAdapter extends CursorAdapter {

    public InventoryAdapter(Context context, Cursor cursor) {
        super(context, cursor, 0);
    }

    @Override
    public View newView(Context context, Cursor cursor, ViewGroup parent) {
        return LayoutInflater.from(context).inflate(R.layout.inventory_item, parent, false);
    }

    @Override
    public void bindView(View view, Context context, Cursor cursor) {
        TextView itemNameTextView = view.findViewById(R.id.itemNameTextView);
        TextView itemQuantityTextView = view.findViewById(R.id.itemQuantityTextView);
        TextView itemDescriptionTextView = view.findViewById(R.id.itemDescriptionTextView);

        String itemName = cursor.getString(cursor.getColumnIndexOrThrow("item_name"));
        int itemQuantity = cursor.getInt(cursor.getColumnIndexOrThrow("item_quantity"));
        String itemDescription = cursor.getString(cursor.getColumnIndexOrThrow("item_description"));

        itemNameTextView.setText(itemName);
        itemQuantityTextView.setText(String.valueOf(itemQuantity));
        itemDescriptionTextView.setText(itemDescription);
    }
}
